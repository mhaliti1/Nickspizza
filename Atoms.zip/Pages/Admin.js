import { useEffect, useState } from "react";
import {
  query,
  collection,
  getDocs,
  doc,
  where,
  addDoc,
  orderBy,
  onSnapshot,
} from "firebase/firestore";
import { auth, db } from "../firebase";
import { Button, DialogContent, DialogTitle, Grid, Paper } from "@mui/material";
import { useRecoilState, useRecoilValue } from "recoil";

import Dialog from "@mui/material/Dialog";
import AddEditProduct from "../components/AddProduct";
import { ProductsState } from "../Atoms/atom";
import { Box, Stack } from "@mui/system";
import CssBaseline from "@mui/material/CssBaseline";
import Drawer from "@mui/material/Drawer";

const drawerWidth = 240;

export default function Admin() {
  const [loading, setloading] = useState(true);
  const [products, setproducts] = useRecoilState(ProductsState);
  const [product, setproduct] = useState({});
  const [isedit, setisedit] = useState(true);
  const [categories, setcategories] = useState();
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const getdata = async () => {
      const q = await query(collection(db, "Products"));

      console.log(q);

      onSnapshot(q, (querySnapshot) => {
        setproducts(
          querySnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }))
        );
      });

      setloading(false);
    };

    getdata();
  }, []);

  const EditProduct = (data) => {
    setproduct(data);
    setOpen(true);
  };

  const AddProduct = () => {
    setproduct({
      name: "",
      description: "",
      category: "",
      price: 9.99,
      qty: 1,
    });
    setisedit(false);
    setOpen(true);
  };

  const CloseDialog = () => {
    setOpen(false);
  };

  return (
    <Box sx={{ display: "flex" }}>
      <CssBaseline />
      <Drawer
        variant="permanent"
        sx={{
          width: drawerWidth,
          flexShrink: 0,
          [`& .MuiDrawer-paper`]: {
            width: drawerWidth,
            boxSizing: "border-box",
          },
        }}
      ></Drawer>
      <Box
        component="main"
        sx={{ flexGrow: 1, bgcolor: "background.default", p: 3 }}
      >
        <Button onClick={AddProduct}>New Product</Button>
        <Grid
          container
          spacing={1}
          justifyContent="center"
          direction="column"
          alignItems="center"
          style={{ minHeight: "90vh" }}
        >
          <Box display="flex" alignItems="center" justifyContent="center">
            {loading ? "Loading..." : ""}

            <Grid container spacing={2} margin={5}>
              {products.map((item, index) => (
                <Paper
                  key={item.id}
                  elevation={3}
                  style={{
                    padding: 8,
                    margin: 5,
                    width: "300px",
                  }}
                >
                  <Stack spacing={2} direction="row">
                    <div>Name</div>
                    <span>{item.name}</span>
                  </Stack>

                  <div>{item.description}</div>
                  <div>{item.price}</div>

                  <Button variant="contained" onClick={() => EditProduct(item)}>
                    Edit
                  </Button>
                </Paper>
              ))}
            </Grid>
          </Box>
        </Grid>
        <Dialog open={open} maxWidth="sm" fullWidth>
          <DialogContent>
            <AddEditProduct
              item={product}
              edit={isedit}
              options={categories}
              closebox={CloseDialog}
            />
          </DialogContent>
        </Dialog>
      </Box>
    </Box>
  );
}
