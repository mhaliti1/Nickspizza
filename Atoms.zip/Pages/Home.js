import React, { useEffect, useState } from "react";
import { useAuthState } from "react-firebase-hooks/auth";
import { useNavigate } from "react-router-dom";

import { auth, db, logout } from "../firebase";
import { query, collection, getDocs, where } from "firebase/firestore";
import { toast } from "react-toastify";
import { Button, Grid, Paper } from "@mui/material";
import { Stack } from "@mui/system";
import { styled } from "@mui/material/styles";

const Item = styled(Paper)(({ theme }) => ({
  backgroundColor: theme.palette.mode === "dark" ? "#1A2027" : "#fff",
  ...theme.typography.body2,
  padding: theme.spacing(1),
  textAlign: "center",
  color: theme.palette.text.secondary,
}));

export default function Home() {
  const [width, setwidth] = useState(window.innerWidth);

  const handleWindowSizeChange = () => {
    setwidth(window.innerWidth);
  };

  useEffect(() => {
    window.addEventListener("resize", handleWindowSizeChange);
  }, [width]);

  const isMobile = width <= 600;

  if (!isMobile) {
    return (
      <>
        <Grid container spacing={1}>
          <Grid item xs={8}>
            <Item
              style={{
                height: "90vh",
                margin: "5px",
                border: "1px solid",
              }}
            ></Item>
          </Grid>
          <Grid item xs={4}>
            <Item
              style={{
                height: "90vh",
                margin: "5px",
                border: "1px solid",
              }}
            ></Item>
          </Grid>
        </Grid>
      </>
    );
  } else {
    return (
      <>
        <Stack spacing={2}>
          <Item>xs</Item>
          <Item>xs</Item>
        </Stack>
      </>
    );
  }
}
