import React, { Fragment, useEffect, useState } from "react";
import { Formik, useFormik } from "formik";
import * as Yup from "yup";
import { Box, Fab, Input, Paper, TextField } from "@mui/material";
import { Stack } from "@mui/system";
import FormControl from "@mui/material/FormControl";
import InputLabel from "@mui/material/InputLabel";
import { db } from "../firebase";
import { addDoc, collection, doc, query, setDoc } from "firebase/firestore";
import Select from "@mui/material/Select";
import MenuItem from "@mui/material/MenuItem";
import Button from "@mui/material/Button";
import { toast } from "react-toastify";
import UploadIcon from "@mui/icons-material/Upload";

export default function AddEditProduct({ item, edit, closebox }) {
  const [initialValues, setinitialValues] = useState(item);
  const [isEdit, setisEdit] = useState(edit);

  const options = ["Pizza", "Pasta", "Salads"];

  const validationSchema = Yup.object({
    name: Yup.string().required("Name is required"),
    description: Yup.string().required("Description is reqired"),
    category: Yup.string().required("Category is required"),
    price: Yup.string().required("price is required"),
  });

  const { handleSubmit, handleChange, values, errors } = useFormik({
    initialValues,
    validationSchema,
    onSubmit(values) {
      if (isEdit) {
        updateproduct(values);
      } else {
        createproduct(values);
      }
    },
  });

  function createproduct(data) {
    try {
      const dbRef = collection(db, "Products");
      addDoc(dbRef, values).then((docRef) => {
        toast.success("Product Added");
      });
    } catch (error) {
      console.log(error);
    }
  }

  function updateproduct(data) {
    try {
      const dbRef = doc(db, "Products", values.id);
      setDoc(dbRef, values).then((docRef) => {
        toast.success("Product Updated");
      });
    } catch (error) {
      console.log(error);
    }
  }

  return (
    <>
      <h3 style={{ padding: "20px" }}></h3>

      <form onSubmit={handleSubmit}>
        <Stack spacing={2}>
          <TextField
            label="Name"
            name="name"
            type="text"
            variant="outlined"
            value={values.name}
            onChange={handleChange}
            placeholder="Enter Product Name"
          />
          {errors.name ? (
            <div style={{ color: "red" }}>{errors.name}</div>
          ) : null}
          <TextField
            label="Description"
            name="description"
            type="text"
            variant="outlined"
            multiline
            rows={3}
            value={values.description}
            onChange={handleChange}
            placeholder="Enter Description"
          />
          {errors.description ? (
            <div style={{ color: "red" }}>{errors.description}</div>
          ) : null}
          <FormControl>
            <InputLabel id="category-label">Category</InputLabel>

            <Select
              labelId="category-label"
              label="category"
              name="category"
              type="text"
              variant="outlined"
              value={values.category}
              onChange={handleChange}
            >
              {options.map((option) => {
                return (
                  <MenuItem key={option} value={option}>
                    {option}
                  </MenuItem>
                );
              })}
            </Select>

            {errors.category ? (
              <div style={{ color: "red" }}>{errors.category}</div>
            ) : null}
          </FormControl>
          <TextField
            label="Price"
            name="price"
            type="price"
            variant="outlined"
            value={values.price}
            onChange={handleChange}
            placeholder="Enter Category"
          />
          {errors.price ? (
            <div style={{ color: "red" }}>{errors.price}</div>
          ) : null}

          <Fab variant="extended">
            <UploadIcon sx={{ mr: 1 }} />
            Upload Image
          </Fab>

          <Button variant="contained" type="submit">
            {isEdit ? "UPDATE" : "CREATE"}
          </Button>
          <Button variant="contained" onClick={closebox}>
            Cancel
          </Button>
        </Stack>
      </form>
    </>
  );
}
