import { Button, Grid, Paper, TextField } from "@mui/material";
import { Box, Stack } from "@mui/system";
import React, { useEffect, useState } from "react";
import { useAuthState } from "react-firebase-hooks/auth";
import { Link, useNavigate } from "react-router-dom";
import { Formik, useFormik } from "formik";
import * as Yup from "yup";
import { auth, registerWithEmailAndPassword } from "../../firebase";

export default function Register() {
  const [user, loading, error] = useAuthState(auth);

  const navigate = useNavigate();

  const validationSchema = Yup.object({
    name: Yup.string().required("Name is required"),
    email: Yup.string().required("Email is reqired"),
    password: Yup.string().required("Password is required").min(5),
  });

  const { handleSubmit, handleChange, values, errors } = useFormik({
    initialValues: {
      name: "",
      email: "",
      password: "",
    },
    validationSchema,
    onSubmit(values) {
      registerWithEmailAndPassword(values.name, values.email, values.password);
    },
  });

  useEffect(() => {
    if (loading) return;
    if (user) navigate("/");
  }, [user, loading]);

  return (
    <Grid
      container
      justifyContent="center"
      spacing={0}
      direction="column"
      alignItems="center"
      style={{ minHeight: "90vh" }}
    >
      <Box sx={{ width: "30%", minWidth: "400px" }}>
        <Paper style={{ padding: "50px" }} elevation={6}>
          <form onSubmit={handleSubmit}>
            <Stack spacing={2}>
              <TextField
                id="outlined-basic"
                label="Full Name"
                name="name"
                type="text"
                variant="outlined"
                value={values.name}
                onChange={handleChange}
                placeholder="Enter Full Name"
              />

              {errors.name ? (
                <div style={{ color: "red" }}>{errors.name}</div>
              ) : null}

              <TextField
                id="outlined-basic"
                label="Email"
                name="email"
                type="email"
                variant="outlined"
                value={values.email}
                onChange={handleChange}
                placeholder="Enter Email Address"
              />
              {errors.email ? (
                <div style={{ color: "red" }}>{errors.email}</div>
              ) : null}

              <TextField
                id="outlined-basic"
                label="Password"
                name="password"
                type="password"
                variant="outlined"
                value={values.password}
                onChange={handleChange}
                placeholder="Enter Password"
              />

              {errors.password ? (
                <div style={{ color: "red" }}>{errors.password}</div>
              ) : null}
              <Button
                variant="contained"
                type="submit"
                style={{ background: "#1ABC9C" }}
              >
                Register
              </Button>
            </Stack>
          </form>
          <br />
          <div>
            Already have an account? <Link to="/login">Login</Link> now.
          </div>
        </Paper>
      </Box>
    </Grid>
  );
}
