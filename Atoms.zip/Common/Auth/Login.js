import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import {
  auth,
  logInWithEmailAndPassword,
  signInWithGoogle,
} from "../../firebase";
import { useAuthState } from "react-firebase-hooks/auth";
import { Button, Grid, Paper, TextField } from "@mui/material";
import { Box } from "@mui/system";
import Stack from "@mui/material/Stack";
import GoogleIcon from "@mui/icons-material/Google";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [user, loading, error] = useAuthState(auth);
  const navigate = useNavigate();

  useEffect(() => {
    if (loading) {
      // maybe trigger a loading screen
      return;
    }
    if (user) navigate("/");
  }, [user, loading]);
  return (
    <Grid
      container
      justifyContent="center"
      spacing={0}
      direction="column"
      alignItems="center"
      style={{ minHeight: "90vh" }}
    >
      <Box sx={{ width: "30%", minWidth: "400px" }}>
        <Paper style={{ padding: "50px" }} elevation={6}>
          <Stack spacing={2}>
            <TextField
              id="outlined-basic"
              label="Email"
              name="email"
              type="text"
              variant="outlined"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="E-mail Address"
            ></TextField>
            <TextField
              id="outlined-basic"
              label="Password"
              name="password"
              type="password"
              variant="outlined"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Password"
            ></TextField>
            <Button
              variant="contained"
              type="submit"
              style={{ background: "#1ABC9C" }}
              onClick={() => logInWithEmailAndPassword(email, password)}
            >
              Login
            </Button>
            <Button
              variant="contained"
              type="submit"
              onClick={signInWithGoogle}
            >
              Login with Google
            </Button>
            <div>
              <Link to="/reset">Forgot Password</Link>
            </div>
            <div>
              {" "}
              Don't have an account? <Link to="/register">Register</Link>
            </div>
          </Stack>
        </Paper>
      </Box>
    </Grid>
  );
}
