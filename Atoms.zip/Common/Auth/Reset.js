import { Button, Grid, Paper, TextField } from "@mui/material";
import { Box, Stack } from "@mui/system";
import React, { useEffect, useState } from "react";
import { useAuthState } from "react-firebase-hooks/auth";
import { useNavigate } from "react-router-dom";
import { Link } from "react-router-dom";
import { auth, sendPasswordReset } from "../../firebase";

export default function Reset() {
  const [email, setEmail] = useState("");
  const [user, loading, error] = useAuthState(auth);
  const navigate = useNavigate();
  useEffect(() => {
    if (loading) return;
    if (user) navigate("/");
  }, [user, loading]);

  return (
    <>
      <Grid
        container
        justifyContent="center"
        spacing={0}
        direction="column"
        alignItems="center"
        style={{ minHeight: "90vh" }}
      >
        <Box sx={{ width: "30%", minWidth: "400px" }}>
          <Paper style={{ padding: "50px" }} elevation={6}>
            <Stack spacing={2}>
              <TextField
                id="outlined-basic"
                label="Email"
                name="email"
                type="text"
                variant="outlined"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="E-mail Address"
              ></TextField>
              <Button
                variant="contained"
                onClick={() => sendPasswordReset(email)}
              >
                Reset Email
              </Button>

              <div>
                Don't have an account? <Link to="/register">Register</Link> now.
              </div>
            </Stack>
          </Paper>
        </Box>
      </Grid>
    </>
  );
}
