import { atom, selector } from "recoil";

export const ProductsState = atom({
  key: "ProductsState",
  default: [],
});
